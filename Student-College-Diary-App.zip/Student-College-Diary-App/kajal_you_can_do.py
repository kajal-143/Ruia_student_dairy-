import tkinter as tk
from tkinter import Label
from PIL import Image, ImageTk
import datetime
from tkcalendar import Calendar
from tkinter import Tk, Toplevel, Canvas, Button, PhotoImage
from tkinter.font import BOLD
from tkinter import ttk

# Function to close the splash screen and show a blank screen
def close_splash():
    splash_frame.destroy()
    root.configure(bg="white")  # Change the background to white after the splash screen closes

# Create Tkinter window
root = tk.Tk()
root.title("Ruia Student Diary")
root.geometry("600x700")  # Set window size to 600x700
root.configure(bg="maroon")  # Set background to maroon
#root.resizable(False, False)  # Disable resizing of the window

# Load image for splash screen
image_path = "images/clg_logo.jpg"  # Change this to your image path
image = Image.open(image_path)
image = image.resize((200, 200))  # Resize the image
photo = ImageTk.PhotoImage(image)

# Create a frame for the splash screen
splash_frame = tk.Frame(root, bg="maroon", width=600, height=700)
splash_frame.pack()

# Display the image on the splash screen
image_label = tk.Label(splash_frame, image=photo, bg="maroon")
image_label.place(relx=0.5, rely=0.5, anchor="center")

# Close splash screen after 3 seconds
root.after(3000, close_splash)

# Create a frame to hold the canvas and scrollbar
frame = tk.Frame(root, bg="white", width=600, height=700)
frame.pack(fill="both", expand=True)

# Create a Canvas widget for the main content
canvas = Canvas(frame, bg="white", width=600, height=700)
canvas.pack(side="left", fill="both", expand=True)

# Add a scrollbar for vertical scrolling on the right
scrollbar = ttk.Scrollbar(frame, command=canvas.yview, orient="vertical")
scrollbar.pack(side="right", fill="y")
canvas.configure(yscrollcommand=scrollbar.set)

# Create a frame to contain the widgets you want to scroll
scroll_frame = tk.Frame(canvas, bg="white")
canvas.create_window((0, 0), window=scroll_frame, anchor="nw") 

# Define get_greeting function if it's not defined elsewhere
def get_greeting():
    return "Welcome to Ruia Student Diary!"

def prev_image(event=None):
    global current_image_index
    current_image_index = (current_image_index - 1) % len(images)
    canvas.itemconfig(image_item, image=images[current_image_index])

def next_image(event=None):
    global current_image_index
    current_image_index = (current_image_index + 1) % len(images)
    canvas.itemconfig(image_item, image=images[current_image_index])



def get_greeting():
        current_time = datetime.datetime.now()
    
        hour = current_time.hour
        if 5 <= hour < 12:
         return "Good Morning,"
        elif 12 <= hour < 18:
            return "Good Afternoon,"
        else:
         return "Good Evening,"


# Get greeting message
greeting = get_greeting()

# Create header
header = tk.Frame(root, bg="maroon", height=120, width=600)
header.pack(fill="x")

# Create label for greeting
greeting_label = tk.Label(header, text=greeting, fg="white", bg="maroon", font=("Arial", 16))
greeting_label.pack(side="left", padx=10, anchor="w")

# Student name (replace "Jagveer Kaur" with actual name)
student_name = "Jagveer Kaur"
name_label = tk.Label(header, text=student_name, fg="white", bg="maroon", font=("Arial", 16))
name_label.pack(side="left", padx=10, anchor="w")

# Load small image within the header
small_image_path = "images/clg_logo.jpg"  # Change this to your small image path
small_image = Image.open(small_image_path)
small_image = small_image.resize((50, 50))  # Resizing the image
small_photo = ImageTk.PhotoImage(small_image)

# Create a Label widget with the small image within the header
small_image_label = tk.Label(header, image=small_photo, bg="maroon")
small_image_label.image = small_photo  # Keep a reference to the image object
small_image_label.pack(side="right", padx=10, pady=10)

# Create a canvas below the header
canvas = tk.Canvas(root, bg="white", width=600, height=120)
canvas.pack()

# Add slideable image
image_paths = ["images/img1.jpg", "images/img2.jpg"]
images = [Image.open(path) for path in image_paths]
images = [image.resize((600, 100)) for image in images]
images = [ImageTk.PhotoImage(image) for image in images]

current_image_index = 0
image_item = canvas.create_image(0, 0, anchor="nw", image=images[current_image_index])

# Bind mouse clicks to change images
canvas.tag_bind(image_item, "<Button-1>", lambda event: next_image())

# Bind arrow keys for image navigation
root.bind("<Right>", next_image)
root.bind("<Left>", prev_image)

# Text below the slideable image
college_text = "Ramnarian Ruia Autonomous College"
college_label = tk.Label(root, text=college_text, font=("Arial", 12, BOLD), bg="white")
college_label.pack()

# Rectangle below the college text (for Attendance, Theory, Practical, Overall)
rectangle1 = tk.Frame(root, bg="#e6e6e6", height=120)
rectangle1.pack(fill="x", pady=10)

# Text on the rectangle1
attendance_text = "Attendance"
theory_text = "Theory"
practical_text = "Practical"
overall_text = "Overall"

attendance_label = tk.Label(rectangle1, text=attendance_text, font=("Arial", 12, BOLD), bg="#e6e6e6", anchor="center")
attendance_label.grid(row=0, column=1, padx=5, pady=10)

theory_label = tk.Label(rectangle1, text=theory_text, font=("Arial", 12), bg="#e6e6e6", anchor="w")
theory_label.grid(row=1, column=0, padx=10, pady=5, sticky="w")

practical_label = tk.Label(rectangle1, text=practical_text, font=("Arial", 12), bg="#e6e6e6", anchor="w")
practical_label.grid(row=2, column=0, padx=10, pady=5, sticky="w")

overall_label = tk.Label(rectangle1, text=overall_text, font=("Arial", 12), bg="#e6e6e6", anchor="w")
overall_label.grid(row=3, column=0, padx=10, pady=5, sticky="w")

# Horizontal bars beside each text on rectangle1
theory_bar = tk.Canvas(rectangle1, bg="white", height=20, width=100, bd=0, highlightthickness=0)
theory_bar.create_rectangle(0, 0, 100, 20, fill="green")
theory_bar.grid(row=1, column=1, padx=(5, 10), pady=5)

practical_bar = tk.Canvas(rectangle1, bg="white", height=20, width=100, bd=0, highlightthickness=0)
practical_bar.create_rectangle(0, 0, 50, 20, fill="blue")
practical_bar.grid(row=2, column=1, padx=(5, 10), pady=5)

overall_bar = tk.Canvas(rectangle1, bg="white", height=20, width=100, bd=0, highlightthickness=0)
overall_bar.create_rectangle(0, 0, 75, 20, fill="red")
overall_bar.grid(row=3, column=1, padx=(5, 10), pady=5)

# Create a white-colored frame to hold the buttons
button_frame = tk.Frame(root, bg="white")
button_frame.pack(pady=20)

# # Definecreate_button1 function
def create_button1(image_path, row, column, command_func=None):
    small_button_image = Image.open(image_path).resize((60, 60))
    small_button_photo = ImageTk.PhotoImage(small_button_image)

    button = tk.Button(
        button_frame,
        image=small_button_photo,
        borderwidth=0,
        command=command_func if command_func else lambda: None
    )
    button.image = small_button_photo
    button.grid(row=row, column=column, padx=5, pady=5)


# Function to open the attendance window
def open_attendance_window():
    new_window = tk.Toplevel(root)
    new_window.title("Attendance")
    new_window.geometry("360x640")

    footer_frame = tk.Frame(new_window, bg="maroon", height=50, width=360)
    footer_frame.pack(side="top", fill="x")

    attendance_label = tk.Label(footer_frame, text="Attendance", fg="white", bg="maroon", font=("Arial", 16))
    attendance_label.pack(side="top", pady=5)

    back_arrow_image = Image.open("images/back_arrow.png")
    back_arrow_image = back_arrow_image.resize((30, 30))
    back_arrow_icon = ImageTk.PhotoImage(back_arrow_image)

    back_button = tk.Button(footer_frame, image=back_arrow_icon, bg="maroon", bd=0, command=new_window.destroy)
    back_button.image = back_arrow_icon
    back_button.pack(side="left", padx=10)
    
# Function to open the class schedule window
def open_schedule_window():
    new_window = tk.Toplevel(root)
    new_window.title("Class Schedule")
    new_window.geometry("360x640")

    # Header Frame
    header_frame = tk.Frame(new_window, bg="maroon", height=50, width=360)
    header_frame.pack(side="top", fill="x")

    # Class Schedule Label in Header
    schedule_label = tk.Label(header_frame, text="Class Schedule", fg="white", bg="maroon", font=("Arial", 16))
    schedule_label.pack(side="top", fill="x", pady=5)

    # Days Frame
    days_frame = tk.Frame(new_window, bg="maroon")
    days_frame.pack(side="top", fill="x")

    # Days of the Week Buttons
    days_of_week = ["MON", "TUE", "WED", "THU", "FRI", "SAT"]

    for day in days_of_week:
        day_button = tk.Button(days_frame, text=day, font=("Arial", 12), fg="white", bg="maroon", padx=100, command=lambda d=day: print(f"{d} clicked!"))
        day_button.pack(side="left")

    # Back Arrow Button
    back_arrow_image = Image.open("images/back_arrow.png")
    back_arrow_image = back_arrow_image.resize((30, 30))
    back_arrow_icon = ImageTk.PhotoImage(back_arrow_image)

    back_button = tk.Button(new_window, image=back_arrow_icon, bg="maroon", bd=0, command=new_window.destroy)
    back_button.image = back_arrow_icon
    back_button.pack(pady=10)

# Function to open online classes
def open_onlineclass_window():
    new_window = tk.Toplevel(root)
    new_window.title("Online Classes")
    new_window.geometry("360x640")

    # Header Frame
    header_frame = tk.Frame(new_window, bg="maroon", height=50, width=360)
    header_frame.pack(side="top", fill="x")

    # Online Classes Label in Header
    onlineclass_label = tk.Label(header_frame, text="Online Classes", fg="white", bg="maroon", font=("Arial", 16))
    onlineclass_label.pack(side="top",pady=5)

    # Buttons for Today, Upcoming, Completed
    button_frame = tk.Frame(new_window, bg="white")
    button_frame.pack(pady=5, expand=True, fill="both")  # Adjusted the padding here

    today_button = tk.Button(button_frame, text="Today", font=("Arial", 12), bg="white", fg="maroon", command=lambda: print("Today clicked!"), width=15)
    today_button.pack(side="left", padx=10)

    upcoming_button = tk.Button(button_frame, text="Upcoming", font=("Arial", 12), bg="white", fg="maroon", command=lambda: print("Upcoming clicked!"), width=15)
    upcoming_button.pack(side="left", padx=10)

    completed_button = tk.Button(button_frame, text="Completed", font=("Arial", 12), bg="white", fg="maroon", command=lambda: print("Completed clicked!"), width=15)
    completed_button.pack(side="left", padx=10)


# Function to open the exam timetable window
def open_examtimetable_window():
    def go_back():
        new_window.destroy()

    new_window = tk.Toplevel(root)
    new_window.title("Exam Timetable")
    new_window.geometry("360x640")

    # Header Frame
    header_frame = tk.Frame(new_window, bg="maroon", height=50, width=360)
    header_frame.pack(side="top", fill="x")

    # Exam Timetable  Label in Header
    examTimetable_label = tk.Label(header_frame, text="Exam Timetable", fg="white", bg="maroon", font=("Arial", 16))
    examTimetable_label.pack(pady=5)

    # Form Frame
    form_frame = tk.Frame(new_window, bg="white")
    form_frame.pack(pady=20)

    # Session Label and Drop-down
    session_label = tk.Label(form_frame, text="Session", font=("Arial", 12), bg="white")
    session_label.grid(row=0, column=0, padx=10, pady=5, sticky="w")

    session_options = ["MARCH-2024 (NEP)", "OCTOBER-2023 (NEP)", "FEBRUARY-2024 ONDE (NEP)"]  # Example options
    session_var = tk.StringVar(value=session_options[0])
    session_dropdown = ttk.Combobox(form_frame, values=session_options, textvariable=session_var, state="readonly")
    session_dropdown.grid(row=0, column=1, padx=10, pady=5, sticky="w")

    # Course Label and Drop-down
    course_label = tk.Label(form_frame, text="Course", font=("Arial", 12), bg="white")
    course_label.grid(row=1, column=0, padx=10, pady=5, sticky="w")

    course_options = ["FYB.SC. COMPUTER SCIENCE SEMESTER I","FYB.SC. COMPUTER SCIENCE SEMESTER II"]  # Example options
    course_var = tk.StringVar(value=course_options[0])
    course_dropdown = ttk.Combobox(form_frame, values=course_options, textvariable=course_var, state="readonly")
    course_dropdown.grid(row=1, column=1, padx=10, pady=5, sticky="w")

    # Exam Type Label and Radio Buttons
    examtype_label = tk.Label(form_frame, text="Exam Type", font=("Arial", 12), bg="white")
    examtype_label.grid(row=3, column=0, padx=10, pady=5, sticky="w")

    examtype_var = tk.StringVar(value="Internal")
    internal_radio = tk.Radiobutton(form_frame, text="Internal", variable=examtype_var, value="Internal", bg="white")
    internal_radio.grid(row=3, column=1, padx=10, pady=5, sticky="w")

    external_radio = tk.Radiobutton(form_frame, text="External", variable=examtype_var, value="External", bg="white")
    external_radio.grid(row=3, column=2, padx=10, pady=5, sticky="w")
    # Back arrow button
    back_arrow_image = Image.open("images/back_arrow.png")
    back_arrow_image = back_arrow_image.resize((30, 30))
    back_arrow_icon = ImageTk.PhotoImage(back_arrow_image)

    back_button = tk.Button(header_frame, image=back_arrow_icon, bg="maroon", bd=0, command=go_back)
    back_button.image = back_arrow_icon
    back_button.pack(side="left", padx=10)


# Function to open the exam hall ticket
def open_examhallticket_window():
    def go_back():
        new_window.destroy()

    new_window = tk.Toplevel(root)
    new_window.title("Exam HallTicket")
    new_window.geometry("360x640")

    # Header Frame
    header_frame = tk.Frame(new_window, bg="maroon", height=50, width=360)
    header_frame.pack(side="top", fill="x")

    # Exam HallTicket Label in Header
    examhallticket_label = tk.Label(header_frame, text="Exam HallTicket", fg="white", bg="maroon", font=("Arial", 16))
    examhallticket_label.pack(pady=5)

    # Form Frame
    form_frame = tk.Frame(new_window, bg="white")
    form_frame.pack(pady=20)

    # Session Label and Drop-down
    session_label = tk.Label(form_frame, text="Session", font=("Arial", 12), bg="white")
    session_label.grid(row=0, column=0, padx=10, pady=5, sticky="w")

    session_options = ["MARCH-2024 (NEP)", "OCTOBER-2023 (NEP)", "FEBRUARY-2024 ONDE (NEP)"]  # Example options
    session_var = tk.StringVar(value=session_options[0])
    session_dropdown = ttk.Combobox(form_frame, values=session_options, textvariable=session_var, state="readonly")
    session_dropdown.grid(row=0, column=1, padx=10, pady=5, sticky="w")

    # Course Label and Drop-down
    course_label = tk.Label(form_frame, text="Course", font=("Arial", 12), bg="white")
    course_label.grid(row=1, column=0, padx=10, pady=5, sticky="w")

    course_options = ["FYB.SC. COMPUTER SCIENCE SEMESTER I","FYB.SC. COMPUTER SCIENCE SEMESTER II"]  # Example options
    course_var = tk.StringVar(value=course_options[0])
    course_dropdown = ttk.Combobox(form_frame, values=course_options, textvariable=course_var, state="readonly")
    course_dropdown.grid(row=1, column=1, padx=10, pady=5, sticky="w")

    # Exam Label and Drop-down
    exam_label = tk.Label(form_frame, text="Exam", font=("Arial", 12), bg="white")
    exam_label.grid(row=2, column=0, padx=10, pady=5, sticky="w")

    exam_options = ["Theory-INTERNAL ASSESSMENT"]  # Example options
    exam_var = tk.StringVar(value=exam_options[0])
    exam_dropdown = ttk.Combobox(form_frame, values=exam_options, textvariable=exam_var, state="readonly")
    exam_dropdown.grid(row=2, column=1, padx=10, pady=5, sticky="w")

    # Exam Type Label and Radio Buttons
    examtype_label = tk.Label(form_frame, text="Exam Type", font=("Arial", 12), bg="white")
    examtype_label.grid(row=3, column=0, padx=10, pady=5, sticky="w")

    examtype_var = tk.StringVar(value="Internal")
    internal_radio = tk.Radiobutton(form_frame, text="Internal", variable=examtype_var, value="Internal", bg="white")
    internal_radio.grid(row=3, column=1, padx=10, pady=5, sticky="w")

    external_radio = tk.Radiobutton(form_frame, text="External", variable=examtype_var, value="External", bg="white")
    external_radio.grid(row=3, column=2, padx=10, pady=5, sticky="w")


    # Back arrow button
    back_arrow_image = Image.open("images/back_arrow.png")
    back_arrow_image = back_arrow_image.resize((30, 30))
    back_arrow_icon = ImageTk.PhotoImage(back_arrow_image)

    back_button = tk.Button(header_frame, image=back_arrow_icon, bg="maroon", bd=0, command=go_back)
    back_button.image = back_arrow_icon
    back_button.pack(side="left", padx=10)


# Function to open result
def open_result_window():
    new_window = tk.Toplevel(root)
    new_window.title("Result")
    new_window.geometry("360x640")

    # Header Frame
    header_frame = tk.Frame(new_window, bg="maroon", height=50, width=360)
    header_frame.pack(side="top", fill="x")

    # Result Label in Header
    result_label = tk.Label(header_frame, text="Result", fg="white", bg="maroon", font=("Arial", 16))
    result_label.pack(pady=5)

    # Form Frame
    form_frame = tk.Frame(new_window, bg="white")
    form_frame.pack(pady=20)

    # Session Label and Drop-down
    session_label = tk.Label(form_frame, text="Select Session", font=("Arial", 12), bg="white")
    session_label.grid(row=0, column=0, padx=10, pady=5, sticky="w")

    session_options = [""]
    session_var = tk.StringVar(value=session_options[0])
    session_dropdown = ttk.Combobox(form_frame, values=session_options, textvariable=session_var, state="readonly")
    session_dropdown.grid(row=0, column=1, padx=10, pady=5, sticky="w")

    # Course Label and Drop-down
    course_label = tk.Label(form_frame, text="Select Course", font=("Arial", 12), bg="white")
    course_label.grid(row=1, column=0, padx=10, pady=5, sticky="w")

    course_options = [""]
    course_var = tk.StringVar(value=course_options[0])
    course_dropdown = ttk.Combobox(form_frame, values=course_options, textvariable=course_var, state="readonly")
    course_dropdown.grid(row=1, column=1, padx=10, pady=5, sticky="w")


# Functions to open internal mark
def open_internalmark_window():
    new_window = tk.Toplevel(root)
    new_window.title("Internal Mark")
    new_window.geometry("360x640")

    # Header Frame
    header_frame = tk.Frame(new_window, bg="maroon", height=50, width=360)
    header_frame.pack(side="top", fill="x")

    # Internal Mark Label in Header
    internal_mark_label = tk.Label(header_frame, text="Internal Mark", fg="white", bg="maroon", font=("Arial", 16))
    internal_mark_label.pack(pady=5)

    # Form Frame
    form_frame = tk.Frame(new_window, bg="white")
    form_frame.pack(pady=20)

    # Session Label and Drop-down
    session_label = tk.Label(form_frame, text="Select Session", font=("Arial", 12), bg="white")
    session_label.grid(row=0, column=0, padx=10, pady=5, sticky="w")

    session_options = [""]
    session_var = tk.StringVar(value=session_options[0])
    session_dropdown = ttk.Combobox(form_frame, values=session_options, textvariable=session_var, state="readonly")
    session_dropdown.grid(row=0, column=1, padx=10, pady=5, sticky="w")

# Function to open fees paid
def open_FeesPaid_window():
    new_window = tk.Toplevel(root)
    new_window.title("Fees Paid")
    new_window.geometry("360x640")

    # Header Frame
    header_frame = tk.Frame(new_window, bg="maroon", height=50, width=360)
    header_frame.pack(side="top", fill="x")

    # Fees Paid Label in Header
    fees_paid_label = tk.Label(header_frame, text="Fees Paid", fg="white", bg="maroon", font=("Arial", 16))
    fees_paid_label.pack(pady=5)

    # Form Frame
    form_frame = tk.Frame(new_window, bg="white")
    form_frame.pack(pady=20)

    # Select Course Label and Drop-down
    select_course_label = tk.Label(form_frame, text="Select Course", font=("Arial", 12), bg="white")
    select_course_label.grid(row=0, column=0, padx=10, pady=5, sticky="w")

    course_options = ["FYB.SC COMPUTER SCIENCE SEMESTER II", "FYB.SC COMPUTER SCIENCE I"]  # Add your course options
    course_var = tk.StringVar(value=course_options[0])
    course_dropdown = ttk.Combobox(form_frame, values=course_options, textvariable=course_var, state="readonly")
    course_dropdown.grid(row=0, column=1, padx=10, pady=5, sticky="w")

    # Buttons
    academic_fees_button = tk.Button(form_frame, text="Academic Fees", bg="maroon", fg="white", font=("Arial", 12), command=lambda: print("Academic Fees clicked!"))
    academic_fees_button.grid(row=1, column=0, padx=10, pady=10)

    scholarships_button = tk.Button(form_frame, text="Scholarships", bg="maroon", fg="white", font=("Arial", 12), command=lambda: print("Scholarships clicked!"))
    scholarships_button.grid(row=1, column=1, padx=10, pady=10)

    other_fees_button = tk.Button(form_frame, text="Other Fees", bg="maroon", fg="white", font=("Arial", 12), command=lambda: print("Other Fees clicked!"))
    other_fees_button.grid(row=1, column=2, padx=10, pady=10)
    

# Function to open register subject
def open_registersubject_window():
    new_window = tk.Toplevel(root)
    new_window.title("Register Subject")
    new_window.geometry("360x640")

    # Create a maroon-colored footer at the top
    footer_frame = tk.Frame(new_window, bg="maroon", height=50, width=360)
    footer_frame.pack(side="top", fill="x")

    # Register Subject class label
    Register_Subject_label = tk.Label(footer_frame, text="Register Subject", fg="white", bg="maroon", font=("Arial", 16))
    Register_Subject_label.pack(side="top", pady=5)

    # Grid of Subjects
    subjects = [
        "COMPUTER ORGANIZATION AND ARCHITECTURE",
        "PRACTICALS BASED ON RUSCS.E111",
        "PYTHON PROGRAMMING",
        "PRACTICALS BASED ON RUSCS.E112",
        "WEB PROGRAMMING",
        "PRACTICAL BASED ON RUSVSCCS.E111",
        "OBJECT-ORIENTED PROGRAMMING WITH JAVA",
        "PRACTICAL BASED ON RUSSECCSCS.E111",
        "DESIGN THINKING-II",
        "CREATIVE CONTENT WRITING-II",
        "COMMUNICATION SKILLS",
        "UNDERSTANDING INDIA",
        "COCURRICULAR COURSES"
    ]

    subject_frame = tk.Frame(new_window, bg="white")
    subject_frame.pack(pady=10, padx=10, fill="both", expand=True)

    for i, subject in enumerate(subjects):
        subject_label = tk.Label(subject_frame, text=subject, font=("Arial", 12), bg="white", pady=5, anchor='w')
        subject_label.grid(row=i, column=0, sticky="nsew")


# Function to open career workshop
def open_CareerWorkshop_window():
    new_window = tk.Toplevel(root)
    new_window.title("Career Workshop")
    new_window.geometry("360x640")

    # Create a maroon-colored footer at the top
    footer_frame = tk.Frame(new_window, bg="maroon", height=50, width=360)
    footer_frame.pack(side="top", fill="x")

    # Career Workshop classlabel
    Career_Workshop_label = tk.Label(footer_frame, text="Career Workshop", fg="white", bg="maroon", font=("Arial", 16))
    Career_Workshop_label.pack(side="top", pady=5)

# Function to open certificate
def open_Certificate_window():
    new_window = tk.Toplevel(root)
    new_window.title("Certificate")
    new_window.geometry("360x640")

    # Create a maroon-colored footer at the top
    footer_frame = tk.Frame(new_window, bg="maroon", height=50, width=360)
    footer_frame.pack(side="top", fill="x")

    # Certificate class label
    Certificate_label = tk.Label(footer_frame, text="Certificate", fg="white", bg="maroon", font=("Arial", 16))
    Certificate_label.pack(side="top", pady=5)

    # Function to open Bonofide Certificate window
    def open_bonofide_window():
        bonofide_window = tk.Toplevel(new_window)
        bonofide_window.title("Bonofide Certificate")
        bonofide_window.geometry("360x640")

        # Header Frame
        bonofide_header_frame = tk.Frame(bonofide_window, bg="maroon", height=50, width=360)
        bonofide_header_frame.pack(side="top", fill="x")

        # Bonofide Certificate Label in Header
        bonofide_label = tk.Label(bonofide_header_frame, text="Bonofide Certificate", fg="white", bg="maroon", font=("Arial", 16))
        bonofide_label.pack(pady=5)

        # Session Label and Drop-down
        session_label = tk.Label(bonofide_window, text="Select Session", font=("Arial", 12), bg="white")
        session_label.pack(pady=10)

        session_options = ["FYB.SC COMPUTER SCIENCE SEMESTER 1", "FYB.SC COMPUTER SCIENCE SEMESTER II"]
        session_var = tk.StringVar(value=session_options[0])
        session_dropdown = ttk.Combobox(bonofide_window, values=session_options, textvariable=session_var, state="readonly")
        session_dropdown.pack(pady=5)

        # Reason Entry
        reason_label = tk.Label(bonofide_window, text="Enter Reason", font=("Arial", 12), bg="white")
        reason_label.pack(pady=10)

        reason_entry = tk.Entry(bonofide_window, font=("Arial", 12))
        reason_entry.pack(pady=5)

        # Apply Bonofide Button
        apply_bonofide_button = tk.Button(bonofide_window, text="Apply Bonofide", bg="maroon", fg="white", font=("Arial", 12))
        apply_bonofide_button.pack(pady=10)

    # Function to open Other Certificate window
    def open_other_certificate_window():
        other_certificate_window = tk.Toplevel(new_window)
        other_certificate_window.title("Other Certificate")
        other_certificate_window.geometry("360x640")

        # Header Frame
        other_certificate_header_frame = tk.Frame(other_certificate_window, bg="maroon", height=50, width=360)
        other_certificate_header_frame.pack(side="top", fill="x")

        # Other Certificate Label in Header
        other_certificate_label = tk.Label(other_certificate_header_frame, text="Other Certificate", fg="white", bg="maroon", font=("Arial", 16))
        other_certificate_label.pack(pady=5)

        # Certificate Type Label and Drop-down
        cert_type_label = tk.Label(other_certificate_window, text="Certificate Type", font=("Arial", 12), bg="white")
        cert_type_label.pack(pady=10)

        cert_type_options = ["BONOFIDE CERTIFICATION", "TRANSCRIPT CERTIFICATE", "RETENTION CERTIFICATE(JUNIOR)", "NOC CERTIFICATE(JUNIOR)", "TRANSFER CERTIFICATE"]
        cert_type_var = tk.StringVar(value=cert_type_options[0])
        cert_type_dropdown = ttk.Combobox(other_certificate_window, values=cert_type_options, textvariable=cert_type_var, state="readonly")
        cert_type_dropdown.pack(pady=5)

        # Fees Bar
        fees_label = tk.Label(other_certificate_window, text="Fees", font=("Arial", 12), bg="white")
        fees_label.pack(pady=10)

        fees_var = tk.DoubleVar(value=0)
        fees_entry = tk.Entry(other_certificate_window, textvariable=fees_var, font=("Arial", 12))
        fees_entry.pack(pady=5)

        # Reason Entry
        reason_label = tk.Label(other_certificate_window, text="Enter Reason", font=("Arial", 12), bg="white")
        reason_label.pack(pady=10)

        reason_entry = tk.Entry(other_certificate_window, font=("Arial", 12))
        reason_entry.pack(pady=5)

        # Number of Copies Frame
        copies_frame = tk.Frame(other_certificate_window, bg="white")
        copies_frame.pack(pady=10)

        copies_label = tk.Label(copies_frame, text="Number of Copies", font=("Arial", 12), bg="white")
        copies_label.pack(side="left")

        copies_options = list(range(1, 11))
        copies_var = tk.IntVar(value=copies_options[0])
        copies_dropdown = ttk.Combobox(copies_frame, values=copies_options, textvariable=copies_var, state="readonly", width=2)
        copies_dropdown.pack(side="left")

        # Apply Button
        apply_button = tk.Button(other_certificate_window, text="Apply", bg="yellow", font=("Arial", 12))
        apply_button.pack(pady=10)

    # Buttons for Bonofide and Other Certificate
    bonofide_button = tk.Button(new_window, text="Bonofide Certificate", command=open_bonofide_window)
    bonofide_button.pack(pady=10)

    other_certificate_button = tk.Button(new_window, text="Other Certificate", command=open_other_certificate_window)
    other_certificate_button.pack(pady=10)
    
# Function to open message
def open_message_window():
    new_window = tk.Toplevel(root)
    new_window.title("MESSAGE")
    new_window.geometry("360x640")

    # Create a maroon-colored footer at the top
    footer_frame = tk.Frame(new_window, bg="maroon", height=50, width=360)
    footer_frame.pack(side="top", fill="x")

    # message classlabel
    message_label = tk.Label(footer_frame, text="MESSAGE", fg="white", bg="maroon", font=("Arial", 16))
    message_label.pack(side="top", pady=5)

# Function to open railway concession apply
def open_Railway_Concession_Apply_window():
    new_window = tk.Toplevel(root)
    new_window.title("Railway Concession Apply")
    new_window.geometry("360x640")

    # Create a maroon-colored footer at the top
    footer_frame = tk.Frame(new_window, bg="maroon", height=50, width=360)
    footer_frame.pack(side="top", fill="x")

    # Railway Concession Apply class label
    Railway_Concession_Apply_label = tk.Label(footer_frame, text="Railway Concession Apply", fg="white", bg="maroon", font=("Arial", 16))
    Railway_Concession_Apply_label.pack(side="top", pady=5)

    # Create a button in the footer with the name "New Application" and maroon background, white text
    new_app_button = tk.Button(footer_frame, text="New Application", bg="maroon", fg="white", font=("Arial", 12))
    new_app_button.pack(side="bottom", pady=5)

# Function to open itle
def open_ITLE_window():
    new_window = tk.Toplevel(root)
    new_window.title("ITLE")
    new_window.geometry("360x640")

    # Create a maroon-colored footer at the top
    footer_frame = tk.Frame(new_window, bg="maroon", height=50, width=360)
    footer_frame.pack(side="top", fill="x")

    # ITLE classlabel
    ITLE_label = tk.Label(footer_frame, text="SUBJECT", fg="white", bg="maroon", font=("Arial", 16))
    ITLE_label.pack(side="top", pady=5)

# Create 14 small image buttons without text below them
create_button1("images/button1.jpg", 0, 0, open_attendance_window)
create_button1("images/button2.jpg", 0, 1, open_schedule_window)
create_button1("images/button3.jpg", 0, 2, open_onlineclass_window)
create_button1("images/button4.jpg", 0, 3, open_examtimetable_window)

create_button1("images/button5.jpg", 1, 0, open_examhallticket_window)
create_button1("images/button6.jpg", 1, 1, open_result_window)
create_button1("images/button7.jpg", 1, 2, open_internalmark_window)
create_button1("images/button8.jpg", 1, 3, open_FeesPaid_window)

create_button1("images/button9.jpg", 2, 0, open_registersubject_window)
create_button1("images/button10.jpg", 2, 1, open_CareerWorkshop_window)
create_button1("images/button11.jpg", 2, 2, open_Certificate_window)
create_button1("images/button12.jpg", 2, 3, open_message_window)

create_button1("images/button13.jpg", 3, 0, open_Railway_Concession_Apply_window)
create_button1("images/button14.jpg", 3, 1, open_ITLE_window)

def create_label(frame, text, color, font, row, column):
    label = tk.Label(frame, text=text, fg=color, font=font, bg="white")
    label.grid(row=row, column=column, rowspan=2, columnspan=3)
    return label

def create_label_header(frame, text, color, font, row, column, columnspan):
    label = tk.Label(frame, text=text, fg=color, font=font, bg="white")
    label.grid(row=row, column=column, columnspan=columnspan, rowspan=3)
    return label

def create_frame(root):
    frame = tk.Frame(root, bg="white", bd=0, relief="raised")
    frame.pack(padx=20, pady=20)
    return frame

def create_separator(frame, row, column):
    separator = ttk.Separator(frame, orient="vertical")
    separator.grid(row=row, column=column, rowspan=2, padx=(10), sticky="ns")
    return separator

# Create the section for Outstanding Fees
outstanding_fees_frame = create_frame(root)

# Create the labels for Outstanding Fees
title_label = create_label_header(outstanding_fees_frame, "Outstanding Fees", None, ("Arial", 13), 0, 1, 7)

paid_label = create_label(outstanding_fees_frame, "₹0", "green", ("Arial Bold", 10), 4, 1)
paid_text = create_label(outstanding_fees_frame, " Paid Fees ", None, ("Arial", 8), 6, 1)

separator = create_separator(outstanding_fees_frame, 5, 4)

balance_label = create_label(outstanding_fees_frame, "₹0", "red", ("Arial Bold", 10), 4, 5)
balance_text = create_label(outstanding_fees_frame, "Balance Fees", None, ("Arial", 8), 6, 5)

# Function to open the profile page
def open_profile_page():
    # Hide the main window (root)
    root.iconify()

    # Create a new window for the profile page
    profile_page = Toplevel(root)
    profile_page.title("Profile Page")
    profile_page.geometry("600x800")
    profile_page.minsize(600, 800)
    profile_page.maxsize(600, 800)

    # Define the height of the maroon section (25% of the window height)
    maroon_height = int(profile_page.winfo_reqheight() * 0.50)

    # Create a Canvas widget
    canvas = Canvas(profile_page, width=600, height=800, bg="white")
    canvas.pack()

    # Draw the maroon section
    canvas.create_rectangle(0, 0, 600, maroon_height, fill="maroon", outline="")

    # Load the image
    # Replace with the actual path to your image
    image_path = "images/dummy_profile.jpg"
    image = Image.open(image_path)
    image = image.resize((100, 100))  # Adjust the size as needed
    photo = ImageTk.PhotoImage(image)

    # Create an image item on the canvas
    image_item = canvas.create_image(50, maroon_height // 2, anchor="center", image=photo)

    # Keep a reference to the image to prevent it from being garbage collected
    canvas.image = photo

    # Create buttons with icons and text
    icon1 = ImageTk.PhotoImage(Image.open("images/icon_1.jpg").resize((30, 30)))
    button1 = Button(profile_page, text="Personal Details", image=icon1, compound="left", command=open_personal_details)
    button1.image = icon1
    button1.place(relx=0.85, rely=0.3, anchor="e")

    icon2 = ImageTk.PhotoImage(Image.open("images/icon_2.jpg").resize((30, 30)))
    button2 = Button(profile_page, text="Contact Details", image=icon2, compound="left", command=open_contact_details)
    button2.image = icon2
    button2.place(relx=0.85, rely=0.4, anchor="e")

    icon3 = ImageTk.PhotoImage(Image.open("images/icon_3.jpg").resize((30, 30)))
    button3 = Button(profile_page, text="Postal Details", image=icon3, compound="left", command=open_postal_details)
    button3.image = icon3
    button3.place(relx=0.85, rely=0.5, anchor="e")

    icon4 = ImageTk.PhotoImage(Image.open("images/icon_4.jpg").resize((30, 30)))
    button4 = Button(profile_page, text="Change Password", image=icon4, compound="left", command=open_change_password)
    button4.image = icon4
    button4.place(relx=0.85, rely=0.6, anchor="e")

    icon5 = ImageTk.PhotoImage(Image.open("images/icon_5.jpg").resize((30, 30)))
    button5 = Button(profile_page, text="Share App", image=icon5, compound="left", command=open_share_app)
    button5.image = icon5
    button5.place(relx=0.85, rely=0.7, anchor="e")

    icon6 = ImageTk.PhotoImage(Image.open("images/icon_6.jpg").resize((30, 30)))
    button6 = Button(profile_page, text="Rate App", image=icon6, compound="left", command=open_rate_app)
    button6.image = icon6
    button6.place(relx=0.85, rely=0.8, anchor="e")

    icon7 = ImageTk.PhotoImage(Image.open("images/icon_7.jpg").resize((30, 30)))
    button7 = Button(profile_page, text="Log Out", image=icon7, compound="left", command=open_log_out)
    button7.image = icon7
    button7.place(relx=0.85, rely=0.9, anchor="e")

    # Create a button to go back to the main window
    back_button = Button(profile_page, text="Back to Main", command=lambda: back_to_main(profile_page))
    back_button.place(relx=0.02, rely=0.95, anchor="sw")

    # Create an "Exit" button to close the profile page
    exit_button = Button(profile_page, text="Exit", command=profile_page.destroy)
    exit_button.place(relx=0.98, rely=0.95, anchor="se")

def open_personal_details():
    # Create a new window for personal details
    personal_details_window = Toplevel(root)
    personal_details_window.title("Personal Details")
    personal_details_window.geometry("600x800")
    personal_details_window.minsize(600, 800)
    personal_details_window.maxsize(600, 800)


    # Load the personal details image
    personal_details_image_path = "images/personal_details.jpg"  # Replace with the actual path
    personal_details_image = Image.open(personal_details_image_path)
    personal_details_image = personal_details_image.resize((500, 700))  # Adjust the size as needed
    personal_details_photo = ImageTk.PhotoImage(personal_details_image)

    # Create an image item on the window
    image_item = Canvas(personal_details_window, width=500, height=700, bg="white")
    image_item.pack()
    image_item.create_image(250, 350, anchor="center", image=personal_details_photo)

    # Keep a reference to the image to prevent it from being garbage collected
    image_item.image = personal_details_photo

    # Create a button to go back to the profile page
    back_button = Button(personal_details_window, text="Back to Profile Page", command=personal_details_window.destroy)
    back_button.pack()


def open_contact_details():
    # Create a new window for contact details
    contact_details_window = Toplevel(root)
    contact_details_window.title("Contact Details")
    contact_details_window.geometry("600x800")
    contact_details_window.minsize(600, 800)
    contact_details_window.maxsize(600, 800)

    # Load the contact details image
    contact_details_image_path = "images/contact_details.jpg"  # Replace with the actual path
    contact_details_image = Image.open(contact_details_image_path)
    contact_details_image = contact_details_image.resize((500, 700))  # Adjust the size as needed
    contact_details_photo = ImageTk.PhotoImage(contact_details_image)

    # Create an image item on the window
    image_item = Canvas(contact_details_window, width=500, height=700, bg="white")
    image_item.pack()
    image_item.create_image(250, 350, anchor="center", image=contact_details_photo)

    # Keep a reference to the image to prevent it from being garbage collected
    image_item.image = contact_details_photo

    # Create a button to go back to the profile page
    back_button = Button(contact_details_window, text="Back to Profile Page", command=contact_details_window.destroy)
    back_button.pack()

def open_postal_details():
    # Create a new window for postal details
    postal_details_window = Toplevel(root)
    postal_details_window.title("Postal Details")
    postal_details_window.geometry("600x800")
    postal_details_window.minsize(600, 800)
    postal_details_window.maxsize(600, 800)

    # Load the postal details image
    postal_details_image_path = "images/postal_deatils.jpg"  # Replace with the actual path
    postal_details_image = Image.open(postal_details_image_path)
    postal_details_image = postal_details_image.resize((500, 700))  # Adjust the size as needed
    postal_details_photo = ImageTk.PhotoImage(postal_details_image)

    # Create an image item on the window
    image_item = Canvas(postal_details_window, width=500, height=700, bg="white")
    image_item.pack()
    image_item.create_image(250, 350, anchor="center", image=postal_details_photo)

    # Keep a reference to the image to prevent it from being garbage collected
    image_item.image = postal_details_photo

    # Create a button to go back to the profile page
    back_button = Button(postal_details_window, text="Back to Profile Page", command=postal_details_window.destroy)
    back_button.pack()


def open_change_password():
    # Create a new window for change password
    change_password_window = Toplevel(root)
    change_password_window.title("Change Password")
    change_password_window.geometry("600x800")
    change_password_window.minsize(600, 800)
    change_password_window.maxsize(600, 800)

    # Load the change password image
    change_password_image_path = "images/change_password.jpg"  # Replace with the actual path
    change_password_image = Image.open(change_password_image_path)
    change_password_image = change_password_image.resize((500, 700))  # Adjust the size as needed
    change_password_photo = ImageTk.PhotoImage(change_password_image)

    # Create an image item on the window
    image_item = Canvas(change_password_window, width=500, height=700, bg="white")
    image_item.pack()
    image_item.create_image(250, 350, anchor="center", image=change_password_photo)

    # Keep a reference to the image to prevent it from being garbage collected
    image_item.image = change_password_photo

    # Create a button to go back to the profile page
    back_button = Button(change_password_window, text="Back to Profile Page", command=change_password_window.destroy)
    back_button.pack()


def open_share_app():
    # Create a new window for sharing the app
    share_app_window = Toplevel(root)
    share_app_window.title("Share App")
    share_app_window.geometry("600x800")
    share_app_window.minsize(600, 800)
    share_app_window.maxsize(600, 800)

    # Load the share app image
    share_app_image_path = "images/share_app.jpg"  # Replace with the actual path
    share_app_image = Image.open(share_app_image_path)
    share_app_image = share_app_image.resize((500, 700))  # Adjust the size as needed
    share_app_photo = ImageTk.PhotoImage(share_app_image)

    # Create an image item on the window
    image_item = Canvas(share_app_window, width=500, height=700, bg="white")
    image_item.pack()
    image_item.create_image(250, 350, anchor="center", image=share_app_photo)

    # Keep a reference to the image to prevent it from being garbage collected
    image_item.image = share_app_photo

    # Create a button to go back to the profile page
    back_button = Button(share_app_window, text="Back to Profile Page", command=share_app_window.destroy)
    back_button.pack()

def open_rate_app():
    # Create a new window for rating the app
    rate_app_window = Toplevel(root)
    rate_app_window.title("Rate App")
    rate_app_window.geometry("600x800")
    rate_app_window.minsize(600, 800)
    rate_app_window.maxsize(600, 800)

    # Load the rate app image
    rate_app_image_path = "images/rate_app.jpg"  # Replace with the actual path
    rate_app_image = Image.open(rate_app_image_path)
    rate_app_image = rate_app_image.resize((500, 700))  # Adjust the size as needed
    rate_app_photo = ImageTk.PhotoImage(rate_app_image)

    # Create an image item on the window
    image_item = Canvas(rate_app_window, width=500, height=700, bg="white")
    image_item.pack()
    image_item.create_image(250, 350, anchor="center", image=rate_app_photo)

    # Keep a reference to the image to prevent it from being garbage collected
    image_item.image = rate_app_photo

    # Create a button to go back to the profile page
    back_button = Button(rate_app_window, text="Back to Profile Page", command=rate_app_window.destroy)
    back_button.pack()


def open_log_out():
    # Create a new window for log out
    log_out_window = Toplevel(root)
    log_out_window.title("Log Out")
    log_out_window.geometry("600x800")
    log_out_window.minsize(600, 800)
    log_out_window.maxsize(600, 800)

    # Load the log out image
    log_out_image_path = "images/log_out.jpg"  # Replace with the actual path
    log_out_image = Image.open(log_out_image_path)
    log_out_image = log_out_image.resize((500, 700))  # Adjust the size as needed
    log_out_photo = ImageTk.PhotoImage(log_out_image)

    # Create an image item on the window
    image_item = Canvas(log_out_window, width=500, height=700, bg="white")
    image_item.pack()
    image_item.create_image(250, 350, anchor="center", image=log_out_photo)

    # Keep a reference to the image to prevent it from being garbage collected
    image_item.image = log_out_photo

    # Create a button to go back to the main profile page
    back_button = Button(log_out_window, text="Back to Profile Page", command=log_out_window.destroy)
    back_button.pack()



# Function to go back to the main window
def back_to_main(profile_page):
    # Close the profile page window and show the main window (root)
    profile_page.destroy()
    root.deiconify()


def open_id_card_page():
    
    # Create a new window for the ID card page
    id_card_page = tk.Toplevel(root)
    id_card_page.title("ID Card Page")
    id_card_page.geometry("600x800")
    id_card_page.minsize(600, 800)
    id_card_page.maxsize(600, 800)

    # Load the ID card image
    id_card_image_path = "images/window_id.jpg"  # Replace with your ID card image path
    id_card_image = Image.open(id_card_image_path)
    id_card_image = id_card_image.resize((500, 700))  # Adjust the size as needed
    id_card_photo = ImageTk.PhotoImage(id_card_image)

    # Create an image label on the ID card page
    id_card_label = tk.Label(id_card_page, image=id_card_photo, bd=0)
    id_card_label.image = id_card_photo
    id_card_label.pack(pady=20)

    # Create a button to go back to the main window
    back_button = tk.Button(id_card_page, text="Back to Main", command=id_card_page.destroy)
    back_button.pack(pady=10)

def back_to_main(open_id_card_page):
    # Close the profile page window and show the main window (root)
    open_id_card_page.destroy()
    root.deiconify()

def open_notification():
    # Create a new window or perform any action you desire
    notification_window = tk.Toplevel(root)
    notification_window.title("Notifications")
    notification_window.geometry("600x800")
    notification_window.minsize(600, 800)
    notification_window.maxsize(600, 800)

    # Load the notification image
    notification_image_path = "images/window_notification.jpg"  # Replace with your image path
    notification_image = Image.open(notification_image_path)
    notification_image = notification_image.resize((500, 700))  # Adjust the size as needed
    notification_photo = ImageTk.PhotoImage(notification_image)

    # Create an image label on the notification window
    notification_image_label = tk.Label(notification_window, image=notification_photo, bd=0)
    notification_image_label.image = notification_photo
    notification_image_label.pack(pady=20)

    # Create a "Back to Main" button
    back_to_main_button = tk.Button(notification_window, text="Back to Main", command=notification_window.destroy)
    back_to_main_button.pack(side="left", padx=10, pady=10)

def back_to_main(open_notification):
    # Close the profile page window and show the main window (root)
    open_notification.destroy()
    root.deiconify()


def open_calendar():
    # Create a new window for the calendar
    calendar_window = tk.Toplevel(root)
    calendar_window.title("Calendar")
    calendar_window.geometry("600x800")
    calendar_window.minsize(600, 800)
    calendar_window.maxsize(600, 800)

    # Create a maroon section
    maroon_height = int(calendar_window.winfo_reqheight() * 0.2)
    maroon_frame = tk.Frame(calendar_window, bg="maroon", height=maroon_height, width=600)
    maroon_frame.pack(side="top", fill="both", expand=True)

    # Create a Calendar widget below the maroon section
    cal_frame = tk.Frame(calendar_window, bg="white")
    cal_frame.pack(side="bottom", fill="both", expand=True)


    # Add calender text below the maroon section
    additional_text = "Calendar"
    additional_label = tk.Label(cal_frame, text=additional_text, fg="black", bg="white", font=("Arial", 16))
    additional_label.pack(pady=10)

    cal = Calendar(cal_frame, selectmode="day", year=2024, month=2, day=16)  # Set the default date as needed
    cal.pack(pady=20)

    # Create the footer frame
    footer_frame = tk.Frame(cal_frame, bg="white", height=400, width=600)
    footer_frame.pack(side="bottom", fill="x")

    # Create a button to close the calendar window
    close_button = tk.Button(cal_frame, text="Back to main", command=calendar_window.destroy)
    close_button.pack(pady=10)

def back_to_main(open_calendar):
    # Close the profile page window and show the main window (root)
    open_calendar.destroy()
    root.deiconify()

# Create footer frame
footer_frame = tk.Frame(root, bg="grey", height=100, width=600)
footer_frame.pack(side="bottom", fill="x")

# Draw semi-circle void
semi_circle_canvas = tk.Canvas(footer_frame, bg="white", width=600, height=50, highlightthickness=0)
semi_circle_canvas.pack()

# Draw maroon button in the void
maroon_button = tk.Button(footer_frame, text="Maroon", bg="maroon", fg="white", width=10)
maroon_button.place(relx=0.5, rely=0.5, anchor="center")

# Draw house symbol button
# Draw maroon circular button in the void with house icon in the center
house_image = Image.open("images/house.jpg")  # Replace with your house symbol image
house_image = house_image.resize((40, 40))  # Adjust the size of the house icon
house_icon = ImageTk.PhotoImage(house_image)

def on_enter(event):
    house_button.config(bg="brown")

def on_leave(event):
    house_button.config(bg="maroon")

house_button = tk.Button(footer_frame, image=house_icon, bg="maroon", bd=0, width=50, height=50, compound="center")  # Adjust the button width and height
house_button.image = house_icon
house_button.place(relx=0.5, rely=0.5, anchor="center")
house_button.bind("<Enter>", on_enter)
house_button.bind("<Leave>", on_leave)

#Draw id card button
id_card_image = Image.open("images/house.jpg")  # Replace with your ID card image
id_card_image = id_card_image.resize((30, 30))
id_card_icon = ImageTk.PhotoImage(id_card_image)
id_card_button = tk.Button(footer_frame, image=id_card_icon, text="ID Card", compound="top", bg="white", bd=0, command=open_id_card_page)
id_card_button.image = id_card_icon
id_card_button.place(relx=0.8, rely=0.5, anchor="center")

# Draw calendar button
calendar_image = Image.open("images/calendar.jpg")  # Replace with your calendar image
calendar_image = calendar_image.resize((30, 30))
calendar_icon = ImageTk.PhotoImage(calendar_image)
calendar_button = tk.Button(footer_frame, image=calendar_icon, text="Calendar", compound="top", bg="white", bd=0, command=open_calendar)
calendar_button.image = calendar_icon
calendar_button.place(relx=0.2, rely=0.5, anchor="center")
calendar_button.config(width=40)

# Draw notification button
notification_image = Image.open("images/notification.jpg")  # Replace with your notification image
notification_image = notification_image.resize((30, 30))
notification_icon = ImageTk.PhotoImage(notification_image)
notification_button = tk.Button(footer_frame, image=notification_icon, text="Notification", compound="top", bg="white", bd=0, command=open_notification)
notification_button.image = notification_icon
notification_button.place(relx=0.4, rely=0.5, anchor="center")

# Draw profile button
profile_image = Image.open("images/profile.jpg")  # Replace with your profile image
profile_image = profile_image.resize((30, 30))
profile_icon = ImageTk.PhotoImage(profile_image)
profile_button = tk.Button(footer_frame, image=profile_icon, text="Profile", compound="top", bg="white", bd=0, command=open_profile_page)
profile_button.image = profile_icon
profile_button.place(relx=0.6, rely=0.5, anchor="center")



# Your additional widgets go inside the scroll_frame
# For example, you can add labels, buttons, etc. to scroll_frame
# ...

# Update the canvas scrolling region
scroll_frame.update_idletasks()
canvas.configure(scrollregion=canvas.bbox("all"))

# Start the Tkinter event loop
root.mainloop()
