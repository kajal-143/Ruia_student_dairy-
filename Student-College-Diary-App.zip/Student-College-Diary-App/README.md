# Student College Diary App
 A student college diary app which would track student's attendance, coursework, ECs, assignments, results and many more stuffs!
