# Create a frame to hold the content
# content_frame = tk.Frame(canvas, bg="#e6e6e6")

# # Add the frame to the canvas
# canvas.create_window((0, 0), window=content_frame, anchor="nw")

# # Update the scroll region
# content_frame.update_idletasks()
# canvas.config(scrollregion=canvas.bbox("all"))

# # Add horizontal scrollbar to canvas for slideable images
# hbar = tk.Scrollbar(button_frame, orient="horizontal", command=canvas.xview)
# hbar.pack(side="bottom", fill="x")
# canvas.config(xscrollcommand=hbar.set)